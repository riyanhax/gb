<?php

echo '<div class="blk"><center>© site.ua</center></div>';


?>