<?
//-----Создаем титл страницы-----//
$title = 'Ошибка';
//-----Подключаем функции-----//
require_once ('../system/function.php');
//-----Подключаем вверх-----//
require_once ('../system/header.php');
include_once 'config_worldkassa.php';
echo '<div class="podmenu"><center><b>Ошибка пополнения!</b></center></div>';
require_once ('../system/footer.php');
?>