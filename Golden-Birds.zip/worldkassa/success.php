<?
//-----Создаем титл страницы-----//
$title = 'Успешно';

include_once '../worldkassa/config_worldkassa.php';

echo '<div class="podmenu"><center><b>Баланс успешно пополнен!</b></center></div>';

?>