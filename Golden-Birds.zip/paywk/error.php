<?
//-----Создаем титл страницы-----//
$title = 'Ошибка';
include ('../inc/head.php');
//-----Создаем титл страницы-----//
$title = 'Пополнить счёт';
//-----Подключаем функции-----//
include ('../inc/config.php');
echo '<div class="podmenu"><center><b>Ошибка при проведении платежа!</b></center></div>';
include ('../inc/foot.php');
?>