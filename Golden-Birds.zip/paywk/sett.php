<?
define('wk_id', ''); //id площадки
define('wk_code', ''); //секретный код

function wk_summ($summ)
{
return number_format(floatval($summ), 2, '.', '');
}
?>